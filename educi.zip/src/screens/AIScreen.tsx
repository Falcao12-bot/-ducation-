import React, { useRef, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, Pressable, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { askAI } from '../services/api';
import { ScreenTitle } from '../components/ui';
import { colors, radius } from '../theme';

type Msg = { role: 'user' | 'assistant'; content: string };
const SUGGESTIONS = ['Explique-moi cette leçon', 'Donne-moi un exercice', 'Explique cette formule', 'Aide-moi à comprendre'];

export default function AIScreen() {
  const [msgs, setMsgs] = useState<Msg[]>([{ role: 'assistant', content: 'Bonjour ! Je suis ton tuteur EduCI. Sur quoi veux-tu travailler ?' }]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const list = useRef<FlatList<Msg>>(null);

  const send = async (t: string) => {
    const content = t.trim();
    if (!content || busy) return;
    const next: Msg[] = [...msgs, { role: 'user', content }];
    setMsgs(next); setText(''); setBusy(true);
    try {
      const reply = await askAI(next.filter((m, i) => !(i === 0 && m.role === 'assistant')));
      setMsgs([...next, { role: 'assistant', content: reply }]);
    } catch (e: any) {
      setMsgs([...next, { role: 'assistant', content: e.message }]);
    } finally { setBusy(false); setTimeout(() => list.current?.scrollToEnd({ animated: true }), 100); }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScreenTitle title="Assistant IA" />
      <FlatList ref={list} data={msgs} keyExtractor={(_, i) => String(i)} contentContainerStyle={{ padding: 16, gap: 10 }}
        onContentSizeChange={() => list.current?.scrollToEnd({ animated: true })}
        renderItem={({ item }) => (
          <View style={{ alignSelf: item.role === 'user' ? 'flex-end' : 'flex-start', maxWidth: '85%', padding: 14, borderRadius: 18,
            backgroundColor: item.role === 'user' ? colors.green : '#fff', borderWidth: item.role === 'user' ? 0 : 1, borderColor: colors.border }}>
            <Text style={{ fontSize: 16, lineHeight: 23, color: item.role === 'user' ? '#fff' : colors.text }}>{item.content}</Text>
          </View>
        )}
        ListFooterComponent={busy ? <Text style={{ color: colors.muted, padding: 8 }}>Le tuteur réfléchit…</Text> : null} />
      {msgs.length === 1 && (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, paddingHorizontal: 16, paddingBottom: 8 }}>
          {SUGGESTIONS.map((s) => (
            <Pressable key={s} onPress={() => send(s)} style={{ paddingHorizontal: 14, paddingVertical: 9, borderRadius: 999, backgroundColor: colors.greenTint }}>
              <Text style={{ color: colors.green, fontWeight: '600' }}>{s}</Text>
            </Pressable>
          ))}
        </View>
      )}
      <View style={{ flexDirection: 'row', gap: 10, padding: 12, backgroundColor: '#fff', alignItems: 'flex-end' }}>
        <TextInput value={text} onChangeText={setText} placeholder="Pose ta question…" placeholderTextColor="#9CA3AF" multiline maxLength={1000}
          style={{ flex: 1, maxHeight: 110, backgroundColor: colors.bg, borderRadius: radius.input, padding: 12, fontSize: 16 }} />
        <Pressable onPress={() => send(text)} style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: colors.green, alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name="send" size={20} color="#fff" />
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}
