import React, { useEffect, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../services/supabase';
import { getClasses } from '../services/api';
import { Button, Chip } from '../components/ui';
import { colors, radius } from '../theme';
import type { ClassRow } from '../types';

const Input = (p: any) => (
  <TextInput placeholderTextColor="#9CA3AF" autoCapitalize="none" {...p}
    style={{ backgroundColor: '#fff', borderRadius: radius.input, borderWidth: 1, borderColor: colors.border, padding: 15, fontSize: 16 }} />
);
const Label = ({ t }: { t: string }) => <Text style={{ fontWeight: '600', color: '#374151', marginBottom: 6 }}>{t}</Text>;

export default function AuthScreen() {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [f, setF] = useState({ first: '', last: '', email: '', pass: '', pass2: '', classId: '' });
  const [classes, setClasses] = useState<ClassRow[]>([]);
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (v: string) => setF((p) => ({ ...p, [k]: v }));

  useEffect(() => { getClasses().then(setClasses).catch(() => {}); }, []);

  const submit = async () => {
    const email = f.email.trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(email)) return Alert.alert('E-mail invalide');
    if (f.pass.length < 8) return Alert.alert('Mot de passe trop court', '8 caractères minimum.');
    setBusy(true);
    try {
      if (mode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({ email, password: f.pass });
        if (error) throw error;
      } else {
        if (!f.first.trim() || !f.last.trim()) throw new Error('Saisissez votre prénom et votre nom.');
        if (f.pass !== f.pass2) throw new Error('Les mots de passe ne correspondent pas.');
        if (!f.classId) throw new Error('Choisissez votre classe.');
        const { data, error } = await supabase.auth.signUp({
          email, password: f.pass,
          options: { data: { first_name: f.first.trim(), last_name: f.last.trim(), class_id: f.classId } },
        });
        if (error) throw error;
        if (!data.session) Alert.alert('Vérifiez vos e-mails', 'Confirmez votre adresse pour vous connecter.');
      }
    } catch (e: any) {
      Alert.alert('Erreur', e.message === 'Invalid login credentials' ? 'E-mail ou mot de passe incorrect.' : e.message);
    } finally { setBusy(false); }
  };

  const forgot = async () => {
    const email = f.email.trim().toLowerCase();
    if (!email) return Alert.alert('Saisissez d\'abord votre e-mail');
    const { error } = await supabase.auth.resetPasswordForEmail(email);
    Alert.alert(error ? 'Erreur' : 'E-mail envoyé', error ? error.message : 'Suivez le lien reçu pour changer votre mot de passe.');
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingBottom: 40 }}>
        <LinearGradient colors={[colors.greenDark, colors.greenLight]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
          style={{ padding: 24, paddingTop: 70, paddingBottom: 40, borderBottomLeftRadius: 40, borderBottomRightRadius: 40 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
            <View style={{ width: 58, height: 58, borderRadius: 18, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="school-outline" size={30} color="#fff" />
            </View>
            <View>
              <Text style={{ color: '#fff', fontSize: 30, fontWeight: '800' }}>EduCI</Text>
              <Text style={{ color: '#E7F7EC' }}>Apprendre. Progresser. Réussir.</Text>
            </View>
          </View>
          <Text style={{ color: '#fff', fontSize: 20, marginTop: 24, lineHeight: 30 }}>Votre plateforme éducative premium en Côte d'Ivoire</Text>
        </LinearGradient>

        <View style={{ padding: 24, gap: 16 }}>
          <View style={{ flexDirection: 'row', backgroundColor: '#F1F1F1', borderRadius: 14, padding: 4 }}>
            {(['login', 'signup'] as const).map((m) => (
              <Pressable key={m} onPress={() => setMode(m)}
                style={{ flex: 1, padding: 12, borderRadius: 11, alignItems: 'center', backgroundColor: mode === m ? '#fff' : 'transparent' }}>
                <Text style={{ fontWeight: '700', color: mode === m ? colors.green : colors.muted }}>{m === 'login' ? 'Connexion' : 'Inscription'}</Text>
              </Pressable>
            ))}
          </View>

          {mode === 'signup' && (
            <View style={{ flexDirection: 'row', gap: 12 }}>
              <View style={{ flex: 1 }}><Label t="Prénom" /><Input value={f.first} onChangeText={set('first')} autoCapitalize="words" /></View>
              <View style={{ flex: 1 }}><Label t="Nom" /><Input value={f.last} onChangeText={set('last')} autoCapitalize="words" /></View>
            </View>
          )}
          <View><Label t="Adresse e-mail" /><Input value={f.email} onChangeText={set('email')} placeholder="exemple@email.com" keyboardType="email-address" /></View>
          <View><Label t="Mot de passe" /><Input value={f.pass} onChangeText={set('pass')} secureTextEntry placeholder="8 caractères minimum" /></View>
          {mode === 'signup' && (
            <>
              <View><Label t="Confirmer le mot de passe" /><Input value={f.pass2} onChangeText={set('pass2')} secureTextEntry /></View>
              <View>
                <Label t="Classe" />
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                  {classes.map((c) => <Chip key={c.id} label={c.name} active={f.classId === c.id} onPress={() => set('classId')(c.id)} />)}
                </View>
              </View>
            </>
          )}
          <Button title={mode === 'login' ? 'Se connecter' : 'Créer mon compte'} onPress={submit} loading={busy} />
          {mode === 'login' && (
            <Pressable onPress={forgot}><Text style={{ color: colors.green, fontWeight: '600', textAlign: 'center' }}>Mot de passe oublié ?</Text></Pressable>
          )}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
