import React, { useCallback, useState } from 'react';
import { Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { useAuth } from '../contexts/AuthContext';
import { getStats } from '../services/api';
import { Button, Card, ScreenTitle } from '../components/ui';
import { StatCard, fmtTime } from '../components/StatCard';
import { colors } from '../theme';
import type { Stats } from '../types';

export default function ProfileScreen({ navigation }: any) {
  const { profile, session, isOwner, signOut } = useAuth();
  const [s, setS] = useState<Stats | null>(null);
  useFocusEffect(useCallback(() => { getStats().then(setS).catch(() => {}); }, []));
  const name = `${profile?.first_name ?? ''} ${profile?.last_name ?? ''}`.trim() || 'Élève';

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScreenTitle title="Profil" />
      <ScrollView contentContainerStyle={{ padding: 16, gap: 14, paddingBottom: 40 }}>
        <Card style={{ alignItems: 'center', gap: 6, paddingVertical: 24 }}>
          <LinearGradient colors={[colors.greenLight, colors.green]} style={{ width: 80, height: 80, borderRadius: 40, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ color: '#fff', fontSize: 34, fontWeight: '800' }}>{name[0]?.toUpperCase()}</Text>
          </LinearGradient>
          <Text style={{ fontSize: 22, fontWeight: '800', marginTop: 6 }}>{name}</Text>
          <Text style={{ color: colors.muted, fontSize: 16 }}>{session?.user.email}</Text>
          <Text style={{ color: colors.green, fontWeight: '700' }}>Classe : {profile?.classes?.name ?? '—'}</Text>
        </Card>

        {!s?.is_premium && (
          <Pressable onPress={() => Alert.alert('Premium', "Le paiement en ligne n'est pas encore activé. Contactez l'administrateur pour passer Premium.")}>
            <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: '#FFF8F0' }}>
              <LinearGradient colors={['#F97316', '#FACC15']} style={{ width: 52, height: 52, borderRadius: 16, alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name="star-outline" size={26} color="#fff" />
              </LinearGradient>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 18, fontWeight: '700' }}>Passer à Premium</Text>
                <Text style={{ color: colors.muted }}>Accédez à tous les contenus et fonctionnalités</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
            </Card>
          </Pressable>
        )}

        <View style={{ flexDirection: 'row', gap: 12 }}>
          <StatCard icon="disc-outline" tint={colors.greenTint} color={colors.green} value={String(s?.exercises_done ?? 0)} label="Exercices" />
          <StatCard icon="time-outline" tint={colors.orangeTint} color={colors.orange} value={fmtTime(s?.study_seconds ?? 0)} label="Temps d'étude" />
        </View>
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <StatCard icon="book-outline" tint={colors.amberTint} color={colors.amber} value={String(s?.lessons_seen ?? 0)} label="Leçons vues" />
          <StatCard icon="ribbon-outline" tint={colors.greenTint} color={colors.green} value="—" label="Moyenne examens" />
        </View>

        {isOwner && <Button title="Espace administrateur" onPress={() => navigation.navigate('AdminDashboard')} />}
        <Button title="Déconnexion" variant="outline" onPress={() => Alert.alert('Déconnexion', 'Se déconnecter ?', [{ text: 'Annuler' }, { text: 'Oui', onPress: signOut }])} />
      </ScrollView>
    </View>
  );
}
