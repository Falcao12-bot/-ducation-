import React, { useEffect, useState } from 'react';
import { FlatList, Linking, Pressable, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getExams } from '../services/api';
import { Card, ErrorText, Loading, ScreenTitle } from '../components/ui';
import { colors, radius, shadow } from '../theme';

const TYPES = ['BAC', 'BEPC', 'CEPE'];
const open = (u?: string) => { if (u && /^https:\/\//.test(u)) Linking.openURL(u); };

export default function ExamsScreen() {
  const [type, setType] = useState('BAC');
  const [items, setItems] = useState<any[] | null>(null);
  const [err, setErr] = useState('');
  useEffect(() => { setItems(null); setErr(''); getExams(type).then(setItems).catch((e) => setErr(e.message)); }, [type]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScreenTitle title="Examens" />
      <View style={{ flexDirection: 'row', gap: 12, padding: 16 }}>
        {TYPES.map((t) => (
          <Pressable key={t} onPress={() => setType(t)} style={[{ flex: 1, height: 84, borderRadius: radius.card, alignItems: 'center', justifyContent: 'center', gap: 6,
            backgroundColor: type === t ? colors.green : '#fff', borderWidth: 1, borderColor: type === t ? colors.green : colors.border }, type === t && shadow]}>
            <Ionicons name="ribbon-outline" size={24} color={type === t ? '#fff' : '#374151'} />
            <Text style={{ fontWeight: '800', fontSize: 17, color: type === t ? '#fff' : '#374151' }}>{t}</Text>
          </Pressable>
        ))}
      </View>
      <Text style={{ fontSize: 20, fontWeight: '800', paddingHorizontal: 16 }}>Sujets disponibles</Text>
      {err ? <ErrorText msg={err} /> : !items ? <Loading /> : (
        <FlatList data={items} keyExtractor={(i) => i.id} contentContainerStyle={{ padding: 16, gap: 12 }}
          ListEmptyComponent={<Text style={{ color: colors.muted, textAlign: 'center', marginTop: 40, fontSize: 16 }}>Aucun sujet disponible pour cet examen</Text>}
          renderItem={({ item }) => (
            <Card style={{ gap: 6 }}>
              <Text style={{ fontSize: 17, fontWeight: '700' }}>{item.title}</Text>
              <Text style={{ color: colors.muted }}>{item.year}{item.serie ? ` · Série ${item.serie}` : ''} · {item.subject}{item.duration_min ? ` · ${item.duration_min} min` : ''}</Text>
              <View style={{ flexDirection: 'row', gap: 16, marginTop: 6 }}>
                {item.pdf_url ? <Pressable onPress={() => open(item.pdf_url)}><Text style={{ color: colors.green, fontWeight: '700' }}>Sujet (PDF)</Text></Pressable> : null}
                {item.correction_url ? <Pressable onPress={() => open(item.correction_url)}><Text style={{ color: colors.orange, fontWeight: '700' }}>Correction</Text></Pressable> : null}
              </View>
            </Card>
          )} />
      )}
    </View>
  );
}
