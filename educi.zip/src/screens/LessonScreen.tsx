import React, { useEffect, useRef, useState } from 'react';
import { Linking, Text, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { getLesson, recordLessonView, recordStudy } from '../services/api';
import { ErrorText, Loading } from '../components/ui';
import { colors } from '../theme';

// Le HTML est affiché dans une WebView SANS JavaScript et avec une CSP stricte :
// même du HTML malveillant ne peut exécuter aucun script (protection XSS).
const wrap = (html: string) => `<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src https: data:; style-src 'unsafe-inline'">
<style>body{font-family:sans-serif;font-size:17px;line-height:1.65;padding:16px;color:#111827;word-wrap:break-word}
h1,h2,h3{color:#0B4F2A}table{border-collapse:collapse;display:block;overflow-x:auto;max-width:100%}
td,th{border:1px solid #D1D5DB;padding:8px 10px}th{background:#F0FAF3}img{max-width:100%;height:auto}
blockquote{border-left:4px solid #16A34A;margin:0;padding-left:12px;color:#374151}</style></head><body>${html}</body></html>`;

export default function LessonScreen({ route, navigation }: any) {
  const { id } = route.params;
  const [lesson, setLesson] = useState<any>(null);
  const [err, setErr] = useState('');
  const start = useRef(Date.now());

  useEffect(() => {
    getLesson(id).then((l) => { setLesson(l); navigation.setOptions({ title: l.title }); recordLessonView(id); })
      .catch((e) => setErr(e.message));
    return () => { recordStudy((Date.now() - start.current) / 1000); };
  }, [id, navigation]);

  if (err) return <ErrorText msg={err} />;
  if (!lesson) return <Loading />;
  return (
    <View style={{ flex: 1, backgroundColor: '#fff' }}>
      {lesson.summary ? (
        <View style={{ padding: 16, backgroundColor: colors.greenTint }}>
          <Text style={{ fontWeight: '700', color: colors.green, marginBottom: 4 }}>Résumé</Text>
          <Text style={{ fontSize: 15, lineHeight: 22 }}>{lesson.summary}</Text>
        </View>
      ) : null}
      <WebView originWhitelist={['about:blank']} source={{ html: wrap(lesson.content_html ?? '<p>Contenu bientôt disponible.</p>') }}
        javaScriptEnabled={false} domStorageEnabled={false} style={{ flex: 1 }}
        onShouldStartLoadWithRequest={(r) => { if (r.url === 'about:blank') return true; if (/^https?:/.test(r.url)) Linking.openURL(r.url); return false; }} />
    </View>
  );
}
