import React, { useCallback, useState } from 'react';
import { FlatList, Pressable, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { useAuth } from '../contexts/AuthContext';
import { getExercises } from '../services/api';
import { Card, Empty, ErrorText, Loading, ScreenTitle } from '../components/ui';
import { colors } from '../theme';

export default function ExercisesScreen({ navigation }: any) {
  const { profile } = useAuth();
  const [items, setItems] = useState<any[] | null>(null);
  const [err, setErr] = useState('');
  useFocusEffect(useCallback(() => {
    if (!profile?.class_id) { setItems([]); return; }
    getExercises(profile.class_id).then(setItems).catch((e) => setErr(e.message));
  }, [profile?.class_id]));

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScreenTitle title="Exercices" />
      {err ? <ErrorText msg={err} /> : !items ? <Loading /> : (
        <FlatList data={items} keyExtractor={(i) => i.id} contentContainerStyle={{ padding: 16, gap: 12, paddingBottom: 30 }}
          ListEmptyComponent={<Empty icon="create-outline" title="Aucun exercice pour votre classe" hint="Les exercices sont organisés par chapitre et matière" />}
          renderItem={({ item }) => (
            <Pressable onPress={() => navigation.navigate('ExercisePlay', { id: item.id })}>
              <Card style={{ gap: 4 }}>
                <Text style={{ fontSize: 17, fontWeight: '700' }}>{item.title}</Text>
                <Text style={{ color: colors.muted }}>{item.chapters?.title} · {item.difficulty} · {item.points} pt{item.points > 1 ? 's' : ''}</Text>
              </Card>
            </Pressable>
          )} />
      )}
    </View>
  );
}
