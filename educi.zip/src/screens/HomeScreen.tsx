import React, { useCallback, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../contexts/AuthContext';
import { getStats } from '../services/api';
import { Card } from '../components/ui';
import { StatCard, fmtTime } from '../components/StatCard';
import { colors } from '../theme';
import type { Stats } from '../types';

const DAILY_GOAL = 5;

export default function HomeScreen() {
  const { profile } = useAuth();
  const { top } = useSafeAreaInsets();
  const [s, setS] = useState<Stats | null>(null);
  useFocusEffect(useCallback(() => { getStats().then(setS).catch(() => {}); }, []));

  const done = s?.today_exercises ?? 0;
  const level = 1 + Math.floor((s?.xp ?? 0) / 100);
  const pill = { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 6, backgroundColor: 'rgba(255,255,255,0.18)', paddingHorizontal: 16, paddingVertical: 10, borderRadius: 16 };

  return (
    <ScrollView style={{ backgroundColor: colors.bg }} contentContainerStyle={{ paddingBottom: 30 }}>
      <LinearGradient colors={[colors.greenDark, colors.greenLight]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={{ paddingTop: top + 28, paddingHorizontal: 20, paddingBottom: 70, borderBottomLeftRadius: 40, borderBottomRightRadius: 40 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <View>
            <Text style={{ color: '#E7F7EC', fontSize: 18 }}>Bonjour,</Text>
            <Text style={{ color: '#fff', fontSize: 34, fontWeight: '800' }}>{profile?.first_name || 'élève'} !</Text>
          </View>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <View style={pill}><Ionicons name="flame-outline" size={20} color="#FDBA74" /><Text style={{ color: '#fff', fontWeight: '700', fontSize: 18 }}>{s?.streak ?? 0}</Text></View>
            <View style={pill}><Ionicons name="star-outline" size={20} color="#FDE047" /><Text style={{ color: '#fff', fontWeight: '700', fontSize: 18 }}>{s?.xp ?? 0} XP</Text></View>
          </View>
        </View>
        <View style={{ marginTop: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
          backgroundColor: 'rgba(255,255,255,0.15)', borderRadius: 20, padding: 16 }}>
          <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center' }}>
            <Ionicons name="school-outline" size={24} color="#fff" />
            <Text style={{ color: '#fff', fontSize: 18, fontWeight: '600' }}>Classe : {profile?.classes?.name ?? '—'}</Text>
          </View>
          <View style={{ backgroundColor: s?.is_premium ? colors.orange : 'rgba(255,255,255,0.25)', paddingHorizontal: 14, paddingVertical: 7, borderRadius: 999 }}>
            <Text style={{ color: '#fff', fontWeight: '700' }}>{s?.is_premium ? 'Premium' : 'Gratuit'}</Text>
          </View>
        </View>
      </LinearGradient>

      <View style={{ paddingHorizontal: 16, marginTop: -44, gap: 12 }}>
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <StatCard icon="disc-outline" tint={colors.greenTint} color={colors.green} value={String(s?.exercises_done ?? 0)} label="Exercices" />
          <StatCard icon="time-outline" tint={colors.orangeTint} color={colors.orange} value={fmtTime(s?.study_seconds ?? 0)} label="Temps d'étude" />
        </View>
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <StatCard icon="trending-up-outline" tint={colors.amberTint} color={colors.amber} value={String(level)} label="Niveau" />
          <StatCard icon="trophy-outline" tint={colors.greenTint} color={colors.green} value={`${s?.streak ?? 0} j`} label="Série" />
        </View>
        <Card style={{ gap: 12 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ fontSize: 20, fontWeight: '700' }}>Objectif du jour</Text>
            <Ionicons name="disc-outline" size={24} color={colors.green} />
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ color: colors.muted, fontSize: 16 }}>Exercices</Text>
            <Text style={{ fontSize: 16 }}>{Math.min(done, DAILY_GOAL)} / {DAILY_GOAL}</Text>
          </View>
          <View style={{ height: 10, borderRadius: 5, backgroundColor: '#E5E7EB', overflow: 'hidden' }}>
            <View style={{ height: 10, width: `${Math.min(100, (done / DAILY_GOAL) * 100)}%`, backgroundColor: colors.greenLight }} />
          </View>
        </Card>
      </View>
    </ScrollView>
  );
}
