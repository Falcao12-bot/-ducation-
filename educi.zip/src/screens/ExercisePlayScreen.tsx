import React, { useEffect, useState } from 'react';
import { ScrollView, Text, TextInput, View, Pressable } from 'react-native';
import { getExercise, submitAnswer } from '../services/api';
import { Button, Card, ErrorText, Loading } from '../components/ui';
import { colors, radius } from '../theme';

export default function ExercisePlayScreen({ route, navigation }: any) {
  const { id } = route.params;
  const [ex, setEx] = useState<any>(null);
  const [answer, setAnswer] = useState('');
  const [result, setResult] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  useEffect(() => { getExercise(id).then((e) => { setEx(e); navigation.setOptions({ title: e.title }); }).catch((e) => setErr(e.message)); }, [id, navigation]);

  const send = async () => {
    if (!answer.trim()) return;
    setBusy(true);
    try { setResult(await submitAnswer(id, answer)); } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };

  if (err) return <ErrorText msg={err} />;
  if (!ex) return <Loading />;
  const options: string[] = ex.type === 'vrai_faux' ? ['Vrai', 'Faux'] : Array.isArray(ex.options) ? ex.options : [];

  return (
    <ScrollView style={{ backgroundColor: colors.bg }} contentContainerStyle={{ padding: 16, gap: 14 }} keyboardShouldPersistTaps="handled">
      {ex.instruction ? <Text style={{ color: colors.muted, fontSize: 15 }}>{ex.instruction}</Text> : null}
      <Card><Text style={{ fontSize: 18, lineHeight: 26 }}>{ex.question}</Text></Card>
      {options.length ? options.map((o) => (
        <Pressable key={o} disabled={!!result} onPress={() => setAnswer(o)}
          style={{ padding: 16, borderRadius: radius.input, borderWidth: 1.5, borderColor: answer === o ? colors.green : colors.border,
            backgroundColor: answer === o ? colors.greenTint : '#fff' }}>
          <Text style={{ fontSize: 16, fontWeight: '600' }}>{o}</Text>
        </Pressable>
      )) : (
        <TextInput value={answer} onChangeText={setAnswer} editable={!result} placeholder="Votre réponse" placeholderTextColor="#9CA3AF"
          keyboardType={ex.type === 'numerique' ? 'numeric' : 'default'}
          style={{ backgroundColor: '#fff', borderRadius: radius.input, borderWidth: 1, borderColor: colors.border, padding: 15, fontSize: 17 }} />
      )}
      {!result ? <Button title="Valider" onPress={send} loading={busy} disabled={!answer.trim()} /> : (
        <Card style={{ gap: 8, borderWidth: 2, borderColor: result.correct ? colors.greenLight : colors.danger }}>
          <Text style={{ fontSize: 20, fontWeight: '800', color: result.correct ? colors.green : colors.danger }}>
            {result.correct ? `Bonne réponse ! +${result.points} pt` : 'Pas tout à fait'}
          </Text>
          <Text>Votre réponse : <Text style={{ fontWeight: '700' }}>{answer}</Text></Text>
          <Text>Bonne réponse : <Text style={{ fontWeight: '700' }}>{result.correct_answer}</Text></Text>
          {result.explanation ? <Text style={{ color: '#374151', lineHeight: 22 }}>{result.explanation}</Text> : null}
          <Button title="Terminer" variant="outline" onPress={() => navigation.goBack()} />
        </Card>
      )}
    </ScrollView>
  );
}
