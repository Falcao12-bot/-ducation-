import React, { useEffect, useMemo, useState } from 'react';
import { FlatList, Pressable, ScrollView, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getChapterCounts, getClasses, getSubjects } from '../services/api';
import { Card, Chip, Empty, ErrorText, Loading, ScreenTitle } from '../components/ui';
import { colors } from '../theme';
import type { ClassRow, Level, Subject } from '../types';

const LEVELS: { key: Level; label: string }[] = [
  { key: 'primaire', label: 'Primaire' }, { key: 'college', label: 'Collège' }, { key: 'lycee', label: 'Lycée' },
];

export default function CoursesScreen({ navigation }: any) {
  const [classes, setClasses] = useState<ClassRow[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [level, setLevel] = useState<Level | null>(null);
  const [cls, setCls] = useState<ClassRow | null>(null);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [err, setErr] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getClasses(), getSubjects()]).then(([c, s]) => { setClasses(c); setSubjects(s); })
      .catch((e) => setErr(e.message)).finally(() => setLoading(false));
  }, []);
  useEffect(() => { if (cls) getChapterCounts(cls.id).then(setCounts).catch((e) => setErr(e.message)); }, [cls]);

  const list = useMemo(() => classes.filter((c) => c.level === level), [classes, level]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScreenTitle title="Cours" />
      <View style={{ padding: 16, flexDirection: 'row', gap: 10 }}>
        {LEVELS.map((l) => <Chip key={l.key} label={l.label} active={level === l.key} onPress={() => { setLevel(l.key); setCls(null); }} />)}
      </View>
      {loading ? <Loading /> : err ? <ErrorText msg={err} /> : !level ? (
        <Empty icon="book-outline" title="Choisissez un niveau pour commencer" hint="Primaire, Collège ou Lycée" />
      ) : (
        <ScrollView contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 30, gap: 12 }}>
          <Text style={{ color: colors.muted, fontSize: 17 }}>Choisir une classe</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
            {list.map((c) => (
              <Pressable key={c.id} onPress={() => setCls(c)} style={{ width: '31%', minHeight: 56, alignItems: 'center', justifyContent: 'center',
                borderRadius: 16, borderWidth: 1, borderColor: cls?.id === c.id ? colors.green : colors.border,
                backgroundColor: cls?.id === c.id ? colors.green : '#fff' }}>
                <Text style={{ fontSize: 18, fontWeight: '600', color: cls?.id === c.id ? '#fff' : colors.text }}>{c.name}</Text>
              </Pressable>
            ))}
          </View>
          {cls && (
            <>
              <Text style={{ color: colors.muted, fontSize: 17, marginTop: 8 }}>Matières</Text>
              {subjects.map((s) => (
                <Pressable key={s.id} onPress={() => navigation.navigate('Subject', { classId: cls.id, subjectId: s.id, title: `${s.name} · ${cls.name}` })}>
                  <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                    <View style={{ width: 50, height: 50, borderRadius: 16, backgroundColor: s.color + '26', alignItems: 'center', justifyContent: 'center' }}>
                      <Ionicons name="book-outline" size={26} color={s.color} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: 19, fontWeight: '700' }}>{s.name}</Text>
                      <Text style={{ color: colors.muted }}>{counts[s.id] ?? 0} chapitre{(counts[s.id] ?? 0) > 1 ? 's' : ''}</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={22} color="#9CA3AF" />
                  </Card>
                </Pressable>
              ))}
            </>
          )}
        </ScrollView>
      )}
    </View>
  );
}
