import React, { useEffect, useState } from 'react';
import { Pressable, SectionList, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getChaptersWithLessons } from '../services/api';
import { Card, Empty, ErrorText, Loading } from '../components/ui';
import { colors } from '../theme';

export default function SubjectScreen({ route, navigation }: any) {
  const { classId, subjectId } = route.params;
  const [sections, setSections] = useState<{ title: string; data: any[] }[] | null>(null);
  const [err, setErr] = useState('');
  useEffect(() => { getChaptersWithLessons(classId, subjectId).then(setSections).catch((e) => setErr(e.message)); }, [classId, subjectId]);

  if (err) return <ErrorText msg={err} />;
  if (!sections) return <Loading />;
  if (!sections.length) return <Empty icon="book-outline" title="Aucun chapitre pour le moment" hint="Les cours seront bientôt disponibles." />;
  return (
    <SectionList sections={sections} keyExtractor={(l) => l.id} style={{ backgroundColor: colors.bg }}
      contentContainerStyle={{ padding: 16, paddingBottom: 40 }} stickySectionHeadersEnabled={false}
      renderSectionHeader={({ section }) => <Text style={{ fontSize: 18, fontWeight: '800', marginTop: 16, marginBottom: 8 }}>{section.title}</Text>}
      renderSectionFooter={({ section }) => section.data.length ? null : <Text style={{ color: colors.muted }}>Aucune leçon publiée.</Text>}
      renderItem={({ item }) => (
        <Pressable onPress={() => navigation.navigate('Lesson', { id: item.id })} style={{ marginBottom: 10 }}>
          <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <Ionicons name="document-text-outline" size={24} color={colors.green} />
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 16, fontWeight: '600' }}>{item.title}</Text>
              {item.duration_min ? <Text style={{ color: colors.muted }}>{item.duration_min} min</Text> : null}
            </View>
            {item.is_premium ? <Ionicons name="star" size={18} color={colors.orange} /> : null}
          </Card>
        </Pressable>
      )} />
  );
}
