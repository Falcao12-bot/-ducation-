import React from 'react';
import { Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Card } from './ui';
import { colors } from '../theme';

export function StatCard({ icon, tint, color, value, label }:
  { icon: keyof typeof Ionicons.glyphMap; tint: string; color: string; value: string; label: string }) {
  return (
    <Card style={{ flex: 1, gap: 10 }}>
      <View style={{ width: 46, height: 46, borderRadius: 14, backgroundColor: tint, alignItems: 'center', justifyContent: 'center' }}>
        <Ionicons name={icon} size={24} color={color} />
      </View>
      <Text style={{ fontSize: 26, fontWeight: '800', color: colors.text }}>{value}</Text>
      <Text style={{ color: colors.muted }}>{label}</Text>
    </Card>
  );
}

export const fmtTime = (s: number) => (s < 60 ? `${s}s` : s < 3600 ? `${Math.round(s / 60)}min` : `${Math.floor(s / 3600)}h${String(Math.round((s % 3600) / 60)).padStart(2, '0')}`);
