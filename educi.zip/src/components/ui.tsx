import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View, ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, radius, shadow } from '../theme';

export const Card = ({ children, style }: { children: React.ReactNode; style?: ViewStyle }) => (
  <View style={[{ backgroundColor: colors.card, borderRadius: radius.card, padding: 16 }, shadow, style]}>{children}</View>
);

export const Button = ({ title, onPress, loading, variant = 'solid', disabled }:
  { title: string; onPress: () => void; loading?: boolean; variant?: 'solid' | 'outline'; disabled?: boolean }) => (
  <Pressable onPress={onPress} disabled={loading || disabled}
    style={{ minHeight: 52, borderRadius: radius.input, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16,
      backgroundColor: variant === 'solid' ? colors.green : 'transparent', borderWidth: variant === 'outline' ? 1.5 : 0,
      borderColor: colors.green, opacity: disabled ? 0.5 : 1 }}>
    {loading ? <ActivityIndicator color={variant === 'solid' ? '#fff' : colors.green} />
      : <Text style={{ color: variant === 'solid' ? '#fff' : colors.green, fontWeight: '700', fontSize: 16 }}>{title}</Text>}
  </Pressable>
);

export const Chip = ({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) => (
  <Pressable onPress={onPress} style={{ paddingHorizontal: 18, paddingVertical: 11, borderRadius: radius.pill,
    backgroundColor: active ? colors.green : '#fff', borderWidth: 1, borderColor: active ? colors.green : colors.border }}>
    <Text style={{ color: active ? '#fff' : colors.text, fontWeight: '600', fontSize: 15 }}>{label}</Text>
  </Pressable>
);

export const Empty = ({ icon, title, hint }: { icon: keyof typeof Ionicons.glyphMap; title: string; hint?: string }) => (
  <View style={{ alignItems: 'center', padding: 32, gap: 8 }}>
    <View style={{ width: 64, height: 64, borderRadius: 20, backgroundColor: colors.greenTint, alignItems: 'center', justifyContent: 'center' }}>
      <Ionicons name={icon} size={30} color={colors.greenLight} />
    </View>
    <Text style={{ fontSize: 17, fontWeight: '600', color: '#374151', textAlign: 'center' }}>{title}</Text>
    {hint ? <Text style={{ color: '#9CA3AF', textAlign: 'center' }}>{hint}</Text> : null}
  </View>
);

export const ScreenTitle = ({ title }: { title: string }) => {
  const { top } = useSafeAreaInsets();
  return (
    <View style={{ paddingTop: top + 12, paddingBottom: 12, paddingHorizontal: 20, backgroundColor: '#fff',
      borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border }}>
      <Text style={{ fontSize: 24, fontWeight: '800', color: colors.text }}>{title}</Text>
    </View>
  );
};

export const Loading = () => <ActivityIndicator style={{ marginTop: 40 }} color={colors.green} />;
export const ErrorText = ({ msg }: { msg: string }) => <Text style={{ color: colors.danger, textAlign: 'center', padding: 16 }}>{msg}</Text>;
