import React from 'react';
import { ActivityIndicator, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../contexts/AuthContext';
import { colors } from '../theme';
import AuthScreen from '../screens/AuthScreen';
import HomeScreen from '../screens/HomeScreen';
import CoursesScreen from '../screens/CoursesScreen';
import SubjectScreen from '../screens/SubjectScreen';
import LessonScreen from '../screens/LessonScreen';
import ExercisesScreen from '../screens/ExercisesScreen';
import ExercisePlayScreen from '../screens/ExercisePlayScreen';
import ExamsScreen from '../screens/ExamsScreen';
import AIScreen from '../screens/AIScreen';
import ProfileScreen from '../screens/ProfileScreen';
import AdminDashboardScreen from '../admin/AdminDashboardScreen';
import { AdminExamForm, AdminExerciseForm, AdminLessonForm } from '../admin/AdminForms';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const ICONS: Record<string, keyof typeof Ionicons.glyphMap> = {
  Accueil: 'home-outline', Cours: 'book-outline', Exercices: 'create-outline', Examens: 'ribbon-outline', IA: 'sparkles-outline', Profil: 'person-outline',
};

function Tabs() {
  const { bottom } = useSafeAreaInsets();
  return (
    <Tab.Navigator screenOptions={({ route }) => ({
      headerShown: false, tabBarActiveTintColor: colors.green, tabBarInactiveTintColor: '#9CA3AF',
      tabBarStyle: { height: 62 + bottom, paddingBottom: bottom + 6, paddingTop: 6 },
      tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
      tabBarIcon: ({ color, size }) => <Ionicons name={ICONS[route.name]} size={size} color={color} />,
    })}>
      <Tab.Screen name="Accueil" component={HomeScreen} />
      <Tab.Screen name="Cours" component={CoursesScreen} />
      <Tab.Screen name="Exercices" component={ExercisesScreen} />
      <Tab.Screen name="Examens" component={ExamsScreen} />
      <Tab.Screen name="IA" component={AIScreen} />
      <Tab.Screen name="Profil" component={ProfileScreen} />
    </Tab.Navigator>
  );
}

export default function RootNavigator() {
  const { session, loading, isOwner } = useAuth();
  if (loading) return <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator color={colors.green} size="large" /></View>;
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerTintColor: colors.green, headerTitleStyle: { color: colors.text }, headerBackTitle: 'Retour' }}>
        {!session ? (
          <Stack.Screen name="Auth" component={AuthScreen} options={{ headerShown: false }} />
        ) : (
          <>
            <Stack.Screen name="Main" component={Tabs} options={{ headerShown: false }} />
            <Stack.Screen name="Subject" component={SubjectScreen} options={({ route }: any) => ({ title: route.params?.title ?? 'Matière' })} />
            <Stack.Screen name="Lesson" component={LessonScreen} options={{ title: 'Leçon' }} />
            <Stack.Screen name="ExercisePlay" component={ExercisePlayScreen} options={{ title: 'Exercice' }} />
            {/* Écrans admin : enregistrés uniquement pour le propriétaire (et re-vérifiés par AdminGuard + RLS) */}
            {isOwner && (
              <>
                <Stack.Screen name="AdminDashboard" component={AdminDashboardScreen} options={{ title: 'Administration' }} />
                <Stack.Screen name="AdminLessonForm" component={AdminLessonForm} options={{ title: 'Nouveau cours' }} />
                <Stack.Screen name="AdminExerciseForm" component={AdminExerciseForm} options={{ title: 'Nouvel exercice' }} />
                <Stack.Screen name="AdminExamForm" component={AdminExamForm} options={{ title: 'Nouvel examen' }} />
              </>
            )}
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
