import React from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { useIsOwner } from './useIsOwner';

export default function AdminGuard({ children }: { children: React.ReactNode }) {
  const { isOwner, loading } = useIsOwner();
  if (loading) return <ActivityIndicator style={{ flex: 1 }} color="#15803D" />;
  if (!isOwner) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        <Text style={{ fontSize: 18, fontWeight: '700' }}>Accès refusé</Text>
        <Text style={{ color: '#6B7280', marginTop: 8, textAlign: 'center' }}>
          Cet espace est réservé au propriétaire de l'application.
        </Text>
      </View>
    );
  }
  return <>{children}</>;
}
