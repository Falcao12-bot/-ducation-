import React from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AdminGuard from './AdminGuard';

const ITEMS = [
  { route: 'AdminLessonForm', label: 'Ajouter un cours', icon: 'book-outline', color: '#15803D' },
  { route: 'AdminExerciseForm', label: 'Ajouter un exercice', icon: 'create-outline', color: '#EA580C' },
  { route: 'AdminExamForm', label: 'Ajouter un examen', icon: 'ribbon-outline', color: '#B45309' },
] as const;

export default function AdminDashboardScreen({ navigation }: any) {
  return (
    <AdminGuard>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 14 }} style={{ backgroundColor: '#FAFAFA' }}>
        <Text style={{ fontSize: 24, fontWeight: '800' }}>Espace administrateur</Text>
        {ITEMS.map((it) => (
          <Pressable key={it.route} onPress={() => navigation.navigate(it.route)}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: '#fff',
              padding: 18, borderRadius: 20, elevation: 2 }}>
            <View style={{ width: 48, height: 48, borderRadius: 14, backgroundColor: it.color + '1A',
              alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name={it.icon} size={24} color={it.color} />
            </View>
            <Text style={{ fontSize: 17, fontWeight: '600', flex: 1 }}>{it.label}</Text>
            <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
          </Pressable>
        ))}
      </ScrollView>
    </AdminGuard>
  );
}
