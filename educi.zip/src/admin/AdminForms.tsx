import React, { useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, Switch, Text, TextInput, View } from 'react-native';
import { supabase } from '../services/supabase';
import AdminGuard from './AdminGuard';

const GREEN = '#15803D';

/* ---------- petits composants ---------- */
const Field = ({ label, ...p }: any) => (
  <View style={{ gap: 6 }}>
    <Text style={{ fontWeight: '600', color: '#374151' }}>{label}</Text>
    <TextInput {...p} placeholderTextColor="#9CA3AF"
      style={[{ backgroundColor: '#fff', borderRadius: 14, borderWidth: 1, borderColor: '#E5E7EB',
        padding: 14, fontSize: 16 }, p.multiline && { minHeight: 110, textAlignVertical: 'top' }]} />
  </View>
);

const Chips = ({ label, value, options, onChange }: any) => (
  <View style={{ gap: 6 }}>
    <Text style={{ fontWeight: '600', color: '#374151' }}>{label}</Text>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
      {options.map((o: any) => {
        const v = o.value ?? o; const on = v === value;
        return (
          <Pressable key={v} onPress={() => onChange(v)}
            style={{ paddingHorizontal: 16, paddingVertical: 10, borderRadius: 999,
              backgroundColor: on ? GREEN : '#fff', borderWidth: 1, borderColor: on ? GREEN : '#E5E7EB' }}>
            <Text style={{ color: on ? '#fff' : '#374151', fontWeight: '600' }}>{o.label ?? o}</Text>
          </Pressable>
        );
      })}
    </ScrollView>
  </View>
);

const PremiumSwitch = ({ value, onChange }: any) => (
  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
    <Text style={{ fontWeight: '600' }}>Contenu Premium</Text>
    <Switch value={value} onValueChange={onChange} trackColor={{ true: GREEN }} />
  </View>
);

function ChapterPicker({ value, onChange }: any) {
  const [chapters, setChapters] = useState<any[]>([]);
  useEffect(() => {
    supabase.from('chapters').select('id,title').order('title').limit(100)
      .then(({ data }) => setChapters(data ?? []));
  }, []);
  return <Chips label="Chapitre" value={value} onChange={onChange}
    options={chapters.map((c) => ({ value: c.id, label: c.title }))} />;
}

function FormShell({ title, table, build, navigation, children }: any) {
  const [busy, setBusy] = useState(false);
  const save = async (status: 'draft' | 'published') => {
    const { payload, error } = build();
    if (error) return Alert.alert('Champ manquant', error);
    setBusy(true);
    const { error: e } = await supabase.from(table).insert({ ...payload, status });
    setBusy(false);
    if (e) return Alert.alert('Erreur', e.message); // RLS refuse si non propriétaire
    Alert.alert(status === 'published' ? 'Publié' : 'Brouillon enregistré');
    navigation.goBack();
  };
  return (
    <AdminGuard>
      <ScrollView style={{ backgroundColor: '#FAFAFA' }} contentContainerStyle={{ padding: 20, gap: 16 }}
        keyboardShouldPersistTaps="handled">
        <Text style={{ fontSize: 22, fontWeight: '800' }}>{title}</Text>
        {children}
        <View style={{ flexDirection: 'row', gap: 12, marginTop: 8 }}>
          <Pressable disabled={busy} onPress={() => save('draft')}
            style={{ flex: 1, padding: 16, borderRadius: 14, borderWidth: 1.5, borderColor: GREEN, alignItems: 'center' }}>
            <Text style={{ color: GREEN, fontWeight: '700' }}>Enregistrer brouillon</Text>
          </Pressable>
          <Pressable disabled={busy} onPress={() => save('published')}
            style={{ flex: 1, padding: 16, borderRadius: 14, backgroundColor: GREEN, alignItems: 'center' }}>
            <Text style={{ color: '#fff', fontWeight: '700' }}>Publier</Text>
          </Pressable>
        </View>
      </ScrollView>
    </AdminGuard>
  );
}

/* ---------- Cours ---------- */
export function AdminLessonForm({ navigation }: any) {
  const [s, set] = useState<any>({ difficulty: 'facile', is_premium: false });
  const u = (k: string) => (v: any) => set((p: any) => ({ ...p, [k]: v }));
  return (
    <FormShell title="Ajouter un cours" table="lessons" navigation={navigation}
      build={() => (!s.chapter_id || !s.title
        ? { error: 'Choisissez un chapitre et saisissez un titre.' }
        : { payload: { chapter_id: s.chapter_id, title: s.title.trim(), summary: s.summary,
            objectives: s.objectives, content_html: s.content_html,
            duration_min: s.duration ? parseInt(s.duration, 10) : null,
            difficulty: s.difficulty, is_premium: s.is_premium } })}>
      <ChapterPicker value={s.chapter_id} onChange={u('chapter_id')} />
      <Field label="Titre" value={s.title} onChangeText={u('title')} placeholder="Développement et factorisation" />
      <Field label="Résumé" value={s.summary} onChangeText={u('summary')} multiline />
      <Field label="Objectifs" value={s.objectives} onChangeText={u('objectives')} multiline />
      <Field label="Contenu (HTML)" value={s.content_html} onChangeText={u('content_html')} multiline />
      <Field label="Durée (min)" value={s.duration} onChangeText={u('duration')} keyboardType="number-pad" />
      <Chips label="Difficulté" value={s.difficulty} onChange={u('difficulty')} options={['facile', 'moyen', 'difficile']} />
      <PremiumSwitch value={s.is_premium} onChange={u('is_premium')} />
    </FormShell>
  );
}

/* ---------- Exercices ---------- */
export function AdminExerciseForm({ navigation }: any) {
  const [s, set] = useState<any>({ type: 'qcm', difficulty: 'facile', points: '1', is_premium: false });
  const u = (k: string) => (v: any) => set((p: any) => ({ ...p, [k]: v }));
  return (
    <FormShell title="Ajouter un exercice" table="exercises" navigation={navigation}
      build={() => (!s.chapter_id || !s.title || !s.question || !s.correct_answer
        ? { error: 'Chapitre, titre, question et bonne réponse sont requis.' }
        : { payload: { chapter_id: s.chapter_id, title: s.title.trim(), type: s.type,
            instruction: s.instruction, question: s.question,
            options: s.type === 'qcm' ? (s.options ?? '').split('\n').map((x: string) => x.trim()).filter(Boolean)
              : s.type === 'vrai_faux' ? ['Vrai', 'Faux'] : [],
            correct_answer: s.correct_answer.trim(), explanation: s.explanation,
            difficulty: s.difficulty, points: parseInt(s.points, 10) || 1, is_premium: s.is_premium } })}>
      <ChapterPicker value={s.chapter_id} onChange={u('chapter_id')} />
      <Chips label="Type" value={s.type} onChange={u('type')}
        options={[{ value: 'qcm', label: 'QCM' }, { value: 'vrai_faux', label: 'Vrai/Faux' },
          { value: 'reponse_courte', label: 'Réponse courte' }, { value: 'numerique', label: 'Numérique' }]} />
      <Field label="Titre" value={s.title} onChangeText={u('title')} />
      <Field label="Consigne" value={s.instruction} onChangeText={u('instruction')} multiline />
      <Field label="Question" value={s.question} onChangeText={u('question')} multiline />
      {s.type === 'qcm' && <Field label="Choix (un par ligne)" value={s.options} onChangeText={u('options')} multiline />}
      <Field label="Bonne réponse" value={s.correct_answer} onChangeText={u('correct_answer')} />
      <Field label="Explication" value={s.explanation} onChangeText={u('explanation')} multiline />
      <Field label="Points" value={s.points} onChangeText={u('points')} keyboardType="number-pad" />
      <Chips label="Difficulté" value={s.difficulty} onChange={u('difficulty')} options={['facile', 'moyen', 'difficile']} />
      <PremiumSwitch value={s.is_premium} onChange={u('is_premium')} />
    </FormShell>
  );
}

/* ---------- Examens ---------- */
export function AdminExamForm({ navigation }: any) {
  const [s, set] = useState<any>({ exam_type: 'BAC', year: String(new Date().getFullYear()), is_premium: false });
  const u = (k: string) => (v: any) => set((p: any) => ({ ...p, [k]: v }));
  return (
    <FormShell title="Ajouter un examen" table="exams" navigation={navigation}
      build={() => (!s.title || !s.subject || !/^\d{4}$/.test(s.year)
        ? { error: 'Titre, matière et année (4 chiffres) sont requis.' }
        : { payload: { exam_type: s.exam_type, year: parseInt(s.year, 10), serie: s.serie,
            subject: s.subject.trim(), title: s.title.trim(),
            duration_min: s.duration ? parseInt(s.duration, 10) : null,
            pdf_url: s.pdf_url, correction_url: s.correction_url, is_premium: s.is_premium } })}>
      <Chips label="Examen" value={s.exam_type} onChange={u('exam_type')} options={['CEPE', 'BEPC', 'BAC']} />
      <Field label="Année" value={s.year} onChangeText={u('year')} keyboardType="number-pad" />
      <Field label="Série (ex. C, D, A1)" value={s.serie} onChangeText={u('serie')} autoCapitalize="characters" />
      <Field label="Matière" value={s.subject} onChangeText={u('subject')} />
      <Field label="Titre du sujet" value={s.title} onChangeText={u('title')} />
      <Field label="Durée (min)" value={s.duration} onChangeText={u('duration')} keyboardType="number-pad" />
      <Field label="Lien PDF du sujet" value={s.pdf_url} onChangeText={u('pdf_url')} autoCapitalize="none" />
      <Field label="Lien PDF de la correction" value={s.correction_url} onChangeText={u('correction_url')} autoCapitalize="none" />
      <PremiumSwitch value={s.is_premium} onChange={u('is_premium')} />
    </FormShell>
  );
}
