export const colors = {
  green: '#15803D', greenDark: '#0B4F2A', greenLight: '#16A34A', greenTint: '#F0FAF3',
  orange: '#EA580C', orangeTint: '#FFF4EC', amber: '#B45309', amberTint: '#FEF9E7',
  bg: '#FAFAFA', card: '#FFFFFF', text: '#111827', muted: '#6B7280', border: '#E5E7EB', danger: '#DC2626',
};
export const shadow = { shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 10, shadowOffset: { width: 0, height: 3 }, elevation: 2 };
export const radius = { card: 20, input: 14, pill: 999 };
