import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '../services/supabase';
import type { Profile } from '../types';

interface Ctx {
  session: Session | null; profile: Profile | null; isOwner: boolean; loading: boolean;
  refreshProfile: () => Promise<void>; signOut: () => Promise<void>;
}
const AuthContext = createContext<Ctx>({} as Ctx);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isOwner, setIsOwner] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async (uid?: string) => {
    if (!uid) { setProfile(null); setIsOwner(false); return; }
    const [p, o] = await Promise.all([
      supabase.from('profiles').select('id,first_name,last_name,class_id,classes(name)').eq('id', uid).maybeSingle(),
      supabase.rpc('is_owner'),
    ]);
    setProfile((p.data as unknown as Profile) ?? null);
    setIsOwner(o.data === true);
  }, []);

  useEffect(() => {
    supabase.auth.getSession().then(async ({ data }) => {
      setSession(data.session); await load(data.session?.user.id); setLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
      setTimeout(() => load(s?.user.id), 0);
    });
    return () => sub.subscription.unsubscribe();
  }, [load]);

  return (
    <AuthContext.Provider value={{
      session, profile, isOwner, loading,
      refreshProfile: () => load(session?.user.id),
      signOut: async () => { await supabase.auth.signOut(); },
    }}>{children}</AuthContext.Provider>
  );
}
