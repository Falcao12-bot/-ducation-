// Edge Function : la clé API reste côté serveur.
// supabase secrets set ANTHROPIC_API_KEY=sk-ant-...   puis   supabase functions deploy ai-tutor
import { createClient } from 'jsr:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  const sb = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
    global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
  });
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return json({ error: 'Non authentifié' }, 401);

  const body = await req.json().catch(() => ({}));
  const messages = (Array.isArray(body.messages) ? body.messages : [])
    .filter((m: any) => (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
    .slice(-12).map((m: any) => ({ role: m.role, content: m.content.slice(0, 2000) }));
  if (!messages.length || messages[messages.length - 1].role !== 'user') return json({ error: 'Message invalide' }, 400);

  const { data: p } = await sb.from('profiles').select('first_name, classes(name, level)').eq('id', user.id).single();
  let lessonCtx = '';
  if (typeof body.lessonId === 'string') {
    const { data: l } = await sb.from('lessons').select('title, summary').eq('id', body.lessonId).maybeSingle();
    if (l) lessonCtx = `\nLeçon en cours : ${l.title}. Résumé : ${l.summary ?? ''}`;
  }
  const cls: any = (p as any)?.classes;
  const system = `Tu es le tuteur d'EduCI, application éducative ivoirienne. L'élève s'appelle ${p?.first_name ?? ''}, classe : ${cls?.name ?? 'inconnue'} (${cls?.level ?? ''}).${lessonCtx}
Adapte ton vocabulaire à ce niveau, réponds en français, de façon courte et claire. Ne donne pas directement la réponse d'un exercice : guide par étapes, pose une question, donne un indice. Pour les formules, écris-les en texte lisible (ex. a² + b² = c²).`;

  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': Deno.env.get('ANTHROPIC_API_KEY')!, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: Deno.env.get('AI_MODEL') ?? 'claude-sonnet-5-5', max_tokens: 800, system, messages }),
  });
  if (!r.ok) return json({ error: 'Service IA indisponible' }, 502);
  const data = await r.json();
  return json({ reply: data.content?.map((c: any) => c.text ?? '').join('') ?? '' });
});
