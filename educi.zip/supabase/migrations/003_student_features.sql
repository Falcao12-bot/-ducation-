-- Progression, statistiques, correction côté serveur, droits du propriétaire
alter table public.lessons   drop constraint if exists lessons_chapter_fk;
alter table public.lessons   add constraint lessons_chapter_fk   foreign key (chapter_id) references public.chapters(id) on delete set null;
alter table public.exercises drop constraint if exists exercises_chapter_fk;
alter table public.exercises add constraint exercises_chapter_fk foreign key (chapter_id) references public.chapters(id) on delete set null;

create table if not exists public.exercise_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  exercise_id uuid not null references public.exercises(id) on delete cascade,
  answer text, correct boolean not null, points_earned int not null default 0,
  created_at timestamptz default now()
);
create table if not exists public.lesson_views (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  created_at timestamptz default now()
);
create table if not exists public.study_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  seconds int not null check (seconds between 1 and 14400),
  created_at timestamptz default now()
);
alter table public.exercise_attempts enable row level security;
alter table public.lesson_views enable row level security;
alter table public.study_sessions enable row level security;
create policy "own attempts" on public.exercise_attempts for select to authenticated using (user_id = auth.uid());
create policy "own views read" on public.lesson_views for select to authenticated using (user_id = auth.uid());
create policy "own views add"  on public.lesson_views for insert to authenticated with check (user_id = auth.uid());
create policy "own sessions read" on public.study_sessions for select to authenticated using (user_id = auth.uid());
create policy "own sessions add"  on public.study_sessions for insert to authenticated with check (user_id = auth.uid());

-- Le propriétaire gère classes/matières/chapitres
do $$ declare t text; begin
  foreach t in array array['classes','subjects','chapters'] loop
    execute format('drop policy if exists "owner write" on public.%I', t);
    execute format('create policy "owner write" on public.%I for all to authenticated using (public.is_owner()) with check (public.is_owner())', t);
  end loop; end $$;

-- Les élèves ne voient JAMAIS la bonne réponse (elle passe par submit_answer)
revoke select on public.exercises from authenticated;
grant select (id, chapter_id, title, type, instruction, question, options, difficulty, points, is_premium, status, created_at)
  on public.exercises to authenticated;
-- Le propriétaire lit tout via cette fonction
create or replace function public.owner_exercise(p_id uuid) returns setof public.exercises
language sql stable security definer set search_path = public as $$
  select * from public.exercises where id = p_id and public.is_owner();
$$;
grant execute on function public.owner_exercise(uuid) to authenticated;

-- Profil : l'élève ne modifie que ses infos
revoke update on public.profiles from authenticated;
grant update (first_name, last_name, class_id, avatar_url) on public.profiles to authenticated;

create or replace function public.submit_answer(p_exercise uuid, p_answer text) returns json
language plpgsql security definer set search_path = public as $$
declare e public.exercises; ok boolean; pts int;
begin
  select * into e from public.exercises
   where id = p_exercise and status = 'published' and (not is_premium or public.has_premium());
  if not found then raise exception 'Exercice indisponible'; end if;
  ok := lower(trim(coalesce(p_answer,''))) = lower(trim(e.correct_answer));
  pts := case when ok then e.points else 0 end;
  insert into public.exercise_attempts (user_id, exercise_id, answer, correct, points_earned)
  values (auth.uid(), e.id, left(p_answer, 500), ok, pts);
  return json_build_object('correct', ok, 'correct_answer', e.correct_answer,
                           'explanation', e.explanation, 'points', pts);
end $$;
grant execute on function public.submit_answer(uuid, text) to authenticated;

create or replace function public.my_stats() returns json
language sql stable security definer set search_path = public as $$
  with d as (
    select distinct created_at::date as day from (
      select created_at from exercise_attempts where user_id = auth.uid()
      union all select created_at from lesson_views where user_id = auth.uid()) x),
  g as (select day, day - (row_number() over (order by day))::int as grp from d)
  select json_build_object(
    'exercises_done', (select count(*) from exercise_attempts where user_id = auth.uid()),
    'today_exercises', (select count(*) from exercise_attempts where user_id = auth.uid() and created_at::date = current_date),
    'lessons_seen', (select count(distinct lesson_id) from lesson_views where user_id = auth.uid()),
    'study_seconds', (select coalesce(sum(seconds),0) from study_sessions where user_id = auth.uid()),
    'xp', (select coalesce(sum(points_earned),0) from exercise_attempts where user_id = auth.uid())
        + (select count(distinct lesson_id) * 5 from lesson_views where user_id = auth.uid()),
    'streak', (select count(*) from g where grp = (select grp from g where day >= current_date - 1 order by day desc limit 1)),
    'is_premium', public.has_premium());
$$;
grant execute on function public.my_stats() to authenticated;
