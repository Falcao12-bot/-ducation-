-- =========================================================
-- EduCI : accès administrateur réservé au PROPRIÉTAIRE
-- =========================================================

-- 1. Table du propriétaire (une seule ligne possible, aucun accès client)
create table if not exists public.app_owner (
  singleton boolean primary key default true check (singleton),
  user_id   uuid not null references auth.users(id) on delete restrict
);
alter table public.app_owner enable row level security;
-- Aucune policy => personne ne peut lire/écrire depuis l'app.

-- 2. Fonction de contrôle utilisée par toutes les policies
create or replace function public.is_owner()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.app_owner where user_id = auth.uid());
$$;
revoke all on function public.is_owner() from public;
grant execute on function public.is_owner() to authenticated;

-- 3. Abonnement premium (validation côté serveur)
create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'active',
  expires_at timestamptz,
  created_at timestamptz default now()
);
alter table public.subscriptions enable row level security;
drop policy if exists "own subscription" on public.subscriptions;
create policy "own subscription" on public.subscriptions
  for select to authenticated using (user_id = auth.uid() or public.is_owner());

create or replace function public.has_premium()
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_owner() or exists (
    select 1 from public.subscriptions
    where user_id = auth.uid() and status = 'active'
      and (expires_at is null or expires_at > now()));
$$;
grant execute on function public.has_premium() to authenticated;

-- 4. Tables de contenu (adaptez si elles existent déjà)
create table if not exists public.lessons (
  id uuid primary key default gen_random_uuid(),
  chapter_id uuid,
  title text not null,
  summary text,
  objectives text,
  content_html text,
  duration_min int,
  difficulty text default 'facile',
  is_premium boolean not null default false,
  status text not null default 'draft' check (status in ('draft','published')),
  created_by uuid default auth.uid(),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.exercises (
  id uuid primary key default gen_random_uuid(),
  chapter_id uuid,
  title text not null,
  type text not null default 'qcm',
  instruction text,
  question text not null,
  options jsonb default '[]',
  correct_answer text not null,
  explanation text,
  difficulty text default 'facile',
  points int not null default 1,
  is_premium boolean not null default false,
  status text not null default 'draft' check (status in ('draft','published')),
  created_by uuid default auth.uid(),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.exams (
  id uuid primary key default gen_random_uuid(),
  exam_type text not null check (exam_type in ('CEPE','BEPC','BAC')),
  year int not null,
  serie text,
  subject text not null,
  title text not null,
  duration_min int,
  pdf_url text,
  correction_url text,
  is_premium boolean not null default false,
  status text not null default 'draft' check (status in ('draft','published')),
  created_by uuid default auth.uid(),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- 5. RLS : lecture élèves = publié (+ premium vérifié serveur) ; écriture = propriétaire
do $$
declare t text;
begin
  foreach t in array array['lessons','exercises','exams'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "read published" on public.%I', t);
    execute format('drop policy if exists "owner write" on public.%I', t);
    execute format($p$create policy "read published" on public.%I for select to authenticated
      using (public.is_owner() or (status = 'published' and (not is_premium or public.has_premium())))$p$, t);
    execute format($p$create policy "owner write" on public.%I for all to authenticated
      using (public.is_owner()) with check (public.is_owner())$p$, t);
  end loop;
end $$;

-- 6. Stockage : seul le propriétaire écrit dans le bucket
insert into storage.buckets (id, name, public)
values ('course-media','course-media', true) on conflict (id) do nothing;
drop policy if exists "owner writes media" on storage.objects;
create policy "owner writes media" on storage.objects for all to authenticated
  using (bucket_id = 'course-media' and public.is_owner())
  with check (bucket_id = 'course-media' and public.is_owner());

-- 7. DÉFINIR LE PROPRIÉTAIRE (à exécuter UNE FOIS dans le SQL Editor,
--    après avoir créé votre compte dans l'app) :
-- insert into public.app_owner (user_id)
--   select id from auth.users where email = 'horizonprogrammeur@gmail.com';
