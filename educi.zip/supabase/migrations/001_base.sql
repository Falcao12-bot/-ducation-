-- Base : classes, matières, chapitres, profils
create table if not exists public.classes (
  id uuid primary key default gen_random_uuid(),
  level text not null check (level in ('primaire','college','lycee')),
  name text not null unique,
  position int not null
);
create table if not exists public.subjects (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  color text not null default '#15803D'
);
create table if not exists public.chapters (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  title text not null,
  position int not null default 0,
  created_at timestamptz default now()
);
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  first_name text not null default '',
  last_name text not null default '',
  class_id uuid references public.classes(id),
  avatar_url text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

insert into public.classes (level, name, position) values
 ('primaire','CP1',1),('primaire','CP2',2),('primaire','CE1',3),('primaire','CE2',4),('primaire','CM1',5),('primaire','CM2',6),
 ('college','6e',7),('college','5e',8),('college','4e',9),('college','3e',10),
 ('lycee','2nde',11),('lycee','1ère',12),('lycee','Terminale',13)
on conflict (name) do nothing;
insert into public.subjects (name, color) values
 ('Français','#E76F51'),('Mathématiques','#2A9D8F'),('Anglais','#457B9D'),('Sciences','#81B29A'),('Histoire','#E9C46A')
on conflict (name) do nothing;

-- Profil créé automatiquement à l'inscription
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, first_name, last_name, class_id)
  values (new.id,
    coalesce(new.raw_user_meta_data->>'first_name',''),
    coalesce(new.raw_user_meta_data->>'last_name',''),
    nullif(new.raw_user_meta_data->>'class_id','')::uuid);
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

alter table public.classes  enable row level security;
alter table public.subjects enable row level security;
alter table public.chapters enable row level security;
alter table public.profiles enable row level security;
-- classes/subjects/chapters lisibles par tout le monde (y compris à l'inscription)
create policy "read classes"  on public.classes  for select to anon, authenticated using (true);
create policy "read subjects" on public.subjects for select to authenticated using (true);
create policy "read chapters" on public.chapters for select to authenticated using (true);
create policy "own profile read"   on public.profiles for select to authenticated using (id = auth.uid());
create policy "own profile update" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
